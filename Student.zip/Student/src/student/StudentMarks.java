/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package student;

/**
 *
 * @author x15004091
 */

import java.util.Scanner;
import java.util.ArrayList;

public class StudentMarks {
    private int id, average;
    private String name;
    private ArrayList<Integer> marks = new ArrayList<>();
    
    private Scanner input = new Scanner(System.in);
    
    public StudentMarks(int id, String name) {
        this.id = id;
        this.name = name;
    }
    
    public StudentMarks() {}
    
    public void inputMarks() {
        int num;
        System.out.println("Enter Marks here[Enter Negative value to finish]");
        for(int i = 1; i > -1; i++) {
            System.out.print("Enter mark " + i + ": ");
            num = input.nextInt();
            if(num < 0) {
                break;
            } else {
                marks.add(num);
            }
        }
    }
    
    private void calculateMarks() {
        int total = 0;
        for(Integer mark : marks) {
            total += mark;
        }
        average = total / marks.size();
    }
    
    public int getAverageMarks() {
        calculateMarks();
        return average;
    }
    
    public void printMarks() {
        for (Integer mark : marks) {
            System.out.println(mark.toString());
        }
    }
}
